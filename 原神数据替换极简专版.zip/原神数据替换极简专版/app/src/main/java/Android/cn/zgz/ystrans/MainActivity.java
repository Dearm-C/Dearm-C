package Android.cn.zgz.ystrans;

import android.Manifest;
import android.app.*;
import android.content.DialogInterface;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.widget.AdapterView.*;
import java.io.File;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.ActivityCompat;
import android.net.Uri;

public class MainActivity extends Activity
{
	//下面方法提前，测试性能
	String extretsn(String path)
	{
		File fs = new File("/storage/emulated/0/Android/data/" + path);
		try
		{
			if (fs.exists() == true)
			{
				return "数据文件存在,路径：\n" + "Android/data/" + path;
			}
			else
			{
				return "数据文件不存在";
			}
		}
		catch (Exception e)
		{
			Toast.makeText(MainActivity.this, "请检查是否已授权读写权限", Toast.LENGTH_LONG).show();
		}
		return null;
	}
	final String local = new String("/storage/emulated/0/Android/data/");
	final String GF = new String("com.miHoYo.Yuanshen");
	final String IF = new String("com.miHoYo.GenshinImpact");
	final String BF = new String("com.miHoYo.ysbilibili");
	//final String[] choi = new String[] { "原神官服  ", "原神国际服  ", "原神B服","打开原神数据替换", "打开云原神", "原神官网", "原神国际服官网", "关于", "帮助" };
	static private String[] permissions = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE};
	static private final int REQUEST_CODE = 200;
    @Override
	protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		//检测某一权限即可，如使用权限组将会导致无法正常判断授权。
		int permuss = ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
		if (permuss != PackageManager.PERMISSION_GRANTED)
		{
			//直接请求授权
			Dialoge1("应用于所需权限作为该页显示的绑定，若您不同意授权，有可能导致应用无法正常使用，请不必担心，我们只需要以下权限：\n\t\t存储空间访问权限");
		}
		else
		{
			Toast.makeText(MainActivity.this, "您已授权，请放心使用", Toast.LENGTH_SHORT).show();
		}
		//初始化列表视图
        setContentView(R.layout.main);
		String[] choice = new String[] { "原神官服  " + extretsn(GF), "原神国际服  " + extretsn(IF), "原神B服 " + extretsn(BF),"打开原神数据替换(com.yuansshujth.app)", "打开云原神", "原神官网", "原神国际服官网", "关于", "帮助" };
		ListAdapter adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, choice);
		//ListAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, choi);
		ListView listView = (ListView) findViewById(R.id.mainListView1);
		listView.setAdapter(adapter1);
		listView.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> l, View v, int position, long id)
				{
					switch (position)
					{
						case 0:
							Toast.makeText(MainActivity.this, "原神官服", Toast.LENGTH_SHORT).show();
							Dialogeplay("原神官服", new String[] {"官服转国际服","官服转B服","删除官服文件夹","启动：打开原神官服"}, "官", local + GF, "国际", local + IF, "B", local + BF, IF, BF, GF);
							break;
						case 1:
							Toast.makeText(MainActivity.this, "原神国际服", Toast.LENGTH_LONG).show();
							Dialogeplay("原神国际服", new String[]{"国际服转官服","国际服转B服","删除国际服文件夹","启动：打开原神国际服"}, "国际", local + IF, "官", local + GF, "B", local + BF, GF, BF, IF);
							break;
						case 2:
							Dialogeplay("原神B服", new String[]{"B服转官服","B服转国际服","删除B服文件夹","启动：打开原神B服"}, "B", local + BF, "官", local + GF, "国际", local + IF, GF, IF, BF);
							Toast.makeText(MainActivity.this, "原神B服", Toast.LENGTH_SHORT).show();
							break;
						case 3:
							startActivity(new Intent(MainActivity.this.getPackageManager().getLaunchIntentForPackage("com.yuansshujth.app")));
							break;
						case 4:
							startActivity(new Intent(MainActivity.this.getPackageManager().getLaunchIntentForPackage("com.miHoYo.cloudgames.ys")));
							break;
						case 5:
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://ys.mihoyo.com")));
							break;
						case 6:
							startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://genshin.hoyoverse.com")));
							break;
						case 7:
							Dialogeplayer("关于", new String[]{"作者：天启星辰","未来开发展望"});
							break;
						case 8:
							break;
					}
				}
				private void Dialogeplay(String title, String[] choices, final String ServeType1, final String opath, final String ServeType2, final String epath, final String ServeType3, final String qPath, final String Package_Name, final String Package_Name1, final String Package_Name2)
				{
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
					builder.setTitle(title);
					builder.setItems(choices, new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								p1.dismiss();
								// 用于显示转换区与启动区
								switch (p2)
								{
									case 0:
										Dialogerename(ServeType1, ServeType2, opath, epath, Package_Name);
										break;
									case 1:
										Dialogerename(ServeType1, ServeType3, opath, qPath, Package_Name1);
										break;
									case 2:
										DeleteDialoge(ServeType1, opath);
										break;
									case 3:
										Intent intent = new Intent(MainActivity.this.getPackageManager().getLaunchIntentForPackage(Package_Name2));
										startActivity(intent);
										break;
								}
							}


						});
					builder.create().show();
				}
				//Helper Alert
				//帮助页，通用
				private void Dialogeplayer(String title, String[] choices)
				{
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
					builder.setTitle(title);
					builder.setItems(choices, new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								p1.dismiss();//窗口消失接口
								//ClickListener
								switch (p2)
								{
									case 0:
										Dialogeplay0("作者信息：", new String[]{"天启星辰","原神官服UID：242924073","WeChat_ID：Coding-linux-lovesfl"});
										break;
									case 1:
										Dialogeplay1("未来开发展望", new String[]{"用户体验优化","应用性能优化"});
										break;
								}
							}

							private void Dialogeplay1(String p0, String[] string)
							{
								// TODO: Implement this method
								AlertDialog.Builder builde = new AlertDialog.Builder(MainActivity.this);
								builde.setTitle(p0);
								builde.setItems(string, new DialogInterface.OnClickListener(){

										@Override
										public void onClick(DialogInterface p1, int p2)
										{
											// TODO: Implement this method
											p1.dismiss();
											switch (p2)
											{
												case 0:
													Dialogeplayerm("用户体验优化", new String[]{"弹窗效果优化","界面设计/布局刷新优化","权限申请体验优化"}, null, null);
													break;
												case 1:
													Dialogeplayerm("应用性能优化", new String[]{"数据可视化优化","程序逻辑优化","权限回调与启动页"}, null, null);
													break;
											}
										}


									});
								builde.create().show();
							}
							private void Dialogeplayerm(String p0, String[] string, String cam0, String cam1)
							{
								// TODO: Implement this method
								AlertDialog.Builder builde = new AlertDialog.Builder(MainActivity.this);
								builde.setTitle(p0);
								builde.setItems(string, new DialogInterface.OnClickListener(){

										@Override
										public void onClick(DialogInterface p1, int p2)
										{
											// TODO: Implement this method
											Dialogeplay1("未来开发展望", new String[]{"用户体验优化","应用性能优化"});
											p1.dismiss();
											switch (p2)
											{
												case 0:

												case 1:
											}
										}
									});
								builde.create().show();
							}
						});
					builder.create().show();
				}
				//帮助页，二层悬浮窗
				private void Dialogeplay0(String title, String[] choices)
				{
					AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
					builder.setTitle(title);
					builder.setItems(choices, new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								p1.dismiss();//窗口隐藏接口
								// Copy and Parse.
								switch (p2)
								{
									case 0:
										Dialogeplayer("关于", new String[]{"作者：天启星辰","未来开发展望"});
										break;
									case 1:
										String cmlip = new String("242924073");
										ClipboardManager clip = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
										clip.setText(cmlip);
										checkclip(cmlip, "原神官服UID");
										break;
									case 2:
										String cmlip2 = new String("Coding-linux-lovesfl");
										ClipboardManager clip2 = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
										clip2.setText(cmlip2);
										checkclip(cmlip2, "WeChat ID");
										break;

								}
							}

							private void checkclip(String clipword, String type)
							{
								Toast.makeText(MainActivity.this, "复制" + type + "成功，" + "内容：\"" + clipword + "\"，请前往剪贴板查看", Toast.LENGTH_SHORT).show();
							}
						});
					builder.create().show();
				}
			});

	}

	//如遇读写类异常错误，使用该提示进行抛出错误
	protected void wrin(String errord)
	{
		Toast.makeText(MainActivity.this, errord, Toast.LENGTH_LONG).show();
	}

	//该弹窗为重命名提示弹窗
	private void Dialogerename(String Serve1, final  String Serve2, final String oldFir, final String newFir, final String intenting)
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("提示");
		builder.setMessage("该操作将会使位于" + oldFir + "的原神" + Serve1 + "服数据文件夹重命名为" + Serve2 + "服的数据文件夹" + newFir + "，确认继续吗？");
		builder.setIcon(R.drawable.alert);
		builder.setPositiveButton("重命名|继续", new DialogInterface.OnClickListener(){
				@Override
				public void onClick(DialogInterface dialog, int which)
				{
					dialog.dismiss();
					try
					{
						transfir(oldFir, newFir);
						String[] choice = new String[] { "原神官服  " + extretsn(GF), "原神国际服  " + extretsn(IF), "原神B服 " + extretsn(BF),"打开原神数据替换(com.yuansshujth.app)", "打开云原神", "原神官网", "原神国际服官网", "关于", "帮助" };
						ListAdapter adapter1 = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, choice);
						ListView listview = (ListView)findViewById(R.id.mainListView1);
						listview.setAdapter(adapter1);
						domer(Serve2, intenting);
					}
					catch (Exception e)
					{
						wrin("文件异常");
					}
				}

				private void domer(String Servertype, final String intenting)
				{
					// TODO: Implement this method
					AlertDialog.Builder builderm = new AlertDialog.Builder(MainActivity.this);
					builderm.setTitle("原神" + Servertype + "服");
					builderm.setMessage("游戏数据已转移，祝您游戏愉快");
					builderm.setPositiveButton("打开游戏", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								try
								{
									startActivity(new Intent(MainActivity.this.getPackageManager().getLaunchIntentForPackage(intenting)));
								}
								catch (Exception e)
								{
									Toast.makeText(MainActivity.this, "请确认是否已安装游戏", Toast.LENGTH_LONG).show();
								}
							}

						});
					builderm.create().show();
				}
			});
		builder.show();
	}
	private File transfir(String Fir1, String Fir2)
	{
		File oldFir =new File(Fir1);
		File newFir =new File(Fir2);
		boolean ma =oldFir.renameTo(newFir);
		File Gile =new File(Fir2);
		return Gile;
	}

	private void Dialoge1(String p0)
	{
		// TODO: 启动弹窗：使用须知
		AlertDialog.Builder build = new AlertDialog.Builder(this);
		build.setTitle("使用须知：");
		build.setMessage(p0);
		build.setIcon(R.drawable.alert);
		build.setCancelable(false);
		build.setPositiveButton("同意|继续使用", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: 二层授权请求弹窗
					Dialoge();}
			});
		build.setNegativeButton("不同意|退出应用", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: 为保证用户体验，强制性硬授权
					Toast.makeText(MainActivity.this, "很遗憾，由于未经授权，您无法使用本应用", Toast.LENGTH_LONG).show();
					finish();
				}


			});
		build.create().show();
	}
	final void sheming(String title, String message)
	{
		AlertDialog.Builder buil = new AlertDialog.Builder(MainActivity.this);
		buil.setTitle(title);
		buil.setMessage(message);
		buil.setIcon(R.drawable.cog);
		buil.create().show();
	}

	private  void Dialoge()
	{
		final String[] smk = new String[]{"存储空间访问权限"};
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("使用须知：\n在使用本应用之前\n" + "请您授权以下权限：\n" + "\n\t\t存储空间访问权限");
		builder.setIcon(R.drawable.cog);
		builder.setCancelable(false);
		builder.setItems(smk, new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					// TODO: Implement this method
					Dialoge();
					sheming("存储访问权限", "访问设备存储，进行删除，重命名等操作");
				}


			});
		builder.setPositiveButton("授权|进入", new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface dialoge, int which)
				{
					try
					{
						requestPermissions(permissions, REQUEST_CODE);
					}
					catch (Exception e)
					{
						Toast.makeText(MainActivity.this, "<(__)>十分抱歉，出现异常了呢<(__)>", Toast.LENGTH_LONG).show();
					}
				}
			});
		builder.setNegativeButton("不同意|退出", new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface Dialog, int which)
				{
					try
					{
						Dl();
					}
					catch (Exception e)
					{
						Toast.makeText(MainActivity.this, "十分抱歉,程序异常终止", Toast.LENGTH_LONG).show();
						finish();
					}
				}

				private void Dl()
				{
					// TODO: Implement this method
					AlertDialog.Builder Dis = new AlertDialog.Builder(MainActivity.this);
					Dis.setTitle("确认退出嘛？\n只需要授权以下权限，" + "\n即可使用本应用：" + "\n\t\t存储空间访问权限");
					Dis.setIcon(R.drawable.alert);
					Dis.setCancelable(false);
					Dis.setItems(smk, new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								Dl();
								sheming("存储访问权限", "访问设备存储，进行删除，重命名等操作");
							}


						});
					Dis.setPositiveButton("继续授权|进入", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								requestPermissions(permissions, REQUEST_CODE);
							}
						});
					Dis.setNegativeButton("仍然退出|拒绝授权", new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface p1, int p2)
							{
								// TODO: Implement this method
								finish();
							}
						});
					Dis.create().show();
				}
			});
		builder.create().show();
	}
	private void DeleteDialoge(String ServeType, final String File_Path)
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("警告");
		builder.setMessage("该操作将会删除位于" + File_Path + "的原神" + ServeType + "服数据文件夹,操作不可逆，请三思而行！！\n\t是否继续？");
		builder.setIcon(R.drawable.delete_variant);
		builder.setPositiveButton("继续|删除", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					p1.dismiss();//弹窗消失
					// TODO: 执行删除操作
					DeleteFolder(File_Path);
					String[] choice = new String[] { "原神官服  " + extretsn(GF), "原神国际服  " + extretsn(IF), "原神B服 " + extretsn(BF),"打开原神数据替换(com.yuansshujth.app)", "打开云原神", "原神官网", "原神国际服官网", "关于", "帮助" };
					ListAdapter adapter1 = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, choice);
					ListView listview = (ListView)findViewById(R.id.mainListView1);
					listview.setAdapter(adapter1);
				}


			});
		builder.create().show();
	}
	/**
     * 删除单个文件
     * @param   filePath    被删除文件的文件名
     * @return 文件删除成功返回true，否则返回false
     */
    public boolean deleteFile(String filePath)
	{
		File file = new File(filePath);
        if (file.isFile() && file.exists())
		{
			return file.delete();
        }
        return false;
    }

    /**
     * 删除文件夹以及目录下的文件
     * @param   filePath 被删除目录的文件路径
     * @return  目录删除成功返回true，否则返回false
     */
    public boolean deleteDirectory(String filePath)
	{
		boolean flag = false;
        //如果filePath不以文件分隔符结尾，自动添加文件分隔符
        if (!filePath.endsWith(File.separator))
		{
            filePath = filePath + File.separator;
        }
        File dirFile = new File(filePath);
        if (!dirFile.exists() || !dirFile.isDirectory())
		{
            return false;
        }
        flag = true;
        File[] files = dirFile.listFiles();
        //遍历删除文件夹下的所有文件(包括子目录)
        for (int i = 0; i < files.length; i++)
		{
            if (files[i].isFile())
			{
				//删除子文件
                flag = deleteFile(files[i].getAbsolutePath());
                if (!flag) break;
            }
			else
			{
				//删除子目录
                flag = deleteDirectory(files[i].getAbsolutePath());
                if (!flag) break;
            }
        }
        if (!flag) return false;
        //删除当前空目录
        return dirFile.delete();
    }

    /**
     *  根据路径删除指定的目录或文件，无论存在与否
     *@param filePath  要删除的目录或文件
     *@return 删除成功返回 true，否则返回 false。
     */
    public boolean DeleteFolder(String filePath)
	{
		File file = new File(filePath);
        if (!file.exists())
		{
            return false;
        }
		else
		{
            if (file.isFile())
			{
				// 为文件时调用删除文件方法
                return deleteFile(filePath);
            }
			else
			{
				// 为目录时调用删除目录方法
                return deleteDirectory(filePath);
            }
        }
    }
}
